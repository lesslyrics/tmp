package testData

/**
 * Fake source file used to test code navigation feature
 */
@Suppress("unused")
class SourceNavigationTarget {

// these empty lines
// do make sense

}