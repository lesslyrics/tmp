package com.github.jk1.ytplugin.issues.model



class IssueLink(myValue: String, myType: String, myRole: String, myUrl: String) {

    var type: String = myType
    var value: String = myValue
    var role: String = myRole
    var url: String  = myUrl

}
