package com.github.jk1.ytplugin.issues.actions

import com.github.jk1.ytplugin.ComponentAware
import com.github.jk1.ytplugin.issues.model.Issue
import com.github.jk1.ytplugin.tasks.YouTrackServer
import com.github.jk1.ytplugin.whenActive
import com.intellij.icons.AllIcons
import com.intellij.openapi.actionSystem.AnActionEvent

/**
 * Takes selected issue from a tool window and sets it as an active Task manager task
 * todo: context switch options: branch, state change, etc
 */
class SetAsActiveTaskAction(private val getSelectedIssue: () -> Issue?, val repo: YouTrackServer) : IssueAction() {

    override val text = "Open Task"
    override val description = "Create a changelist for the selected issue"
    override val icon = AllIcons.ToolbarDecorator.Export
    override val shortcut = "control shift A"

    override fun actionPerformed(event: AnActionEvent) {
        event.whenActive { project ->
            val issue = getSelectedIssue.invoke()
            if (issue != null) {
                with(ComponentAware.of(project)) {
                    taskManagerComponent.setActiveTask(repo.createTask(issue))
                }
            }
        }
    }

    override fun update(event: AnActionEvent) {
        event.presentation.isEnabled = getSelectedIssue.invoke() != null
    }
}