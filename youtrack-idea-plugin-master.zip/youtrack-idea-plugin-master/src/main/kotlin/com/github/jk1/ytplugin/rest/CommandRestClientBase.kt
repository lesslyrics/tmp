package com.github.jk1.ytplugin.rest

import com.github.jk1.ytplugin.commands.model.CommandAssistResponse
import com.github.jk1.ytplugin.commands.model.CommandExecutionResponse
import com.github.jk1.ytplugin.commands.model.YouTrackCommand
import com.github.jk1.ytplugin.commands.model.YouTrackCommandExecution


interface CommandRestClientBase {

    fun assistCommand(command: YouTrackCommand): CommandAssistResponse

    fun executeCommand(command: YouTrackCommandExecution): CommandExecutionResponse
}